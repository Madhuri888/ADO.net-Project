﻿create procedure sp_update
(
@Empid int,@Empname varchar(50),@Dob int,@Phone int,@Email varchar(50),@Salary int,@Deptid int
)
as
begin
	update Employe
	set Empid=@Empid,Dob=@Dob,Phone=@Phone,Email=@Email,Salary=@Salary,Deptid=@Deptid
	where Empname=@Empname;
end

exec sp_update   2,'D',11,1234560,'a@gmail.com',0000,5


select * from Employe;