﻿create procedure update2
(
@Empid int,@Empname varchar(50),@Dob int,@Phone int,@Email varchar(50),@Salary int,@Deptid int
)
as
begin
	update Employe
	set Empname=@Empname,Dob=@Dob,Phone=@Phone,Email=@Email,Salary=@Salary,Deptid=@Deptid
	where EmpId=@Empid;
end

exec update1 @Empid = 4,@Empname= 'D',@Dob=11,@Phone=1234560,@Email='a@gmail.com',@Salary=0000,@Deptid=5


select * from Employe;