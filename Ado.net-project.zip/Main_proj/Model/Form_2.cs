﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj.Model
{
    public partial class btninsert : Form
    {
        DepartementLogic ob;
        public btninsert()
        {
            InitializeComponent();
            ob = new DepartementLogic();
        }

        private void btinsert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hii");
            Departement c= new Departement();
            c.Deptid = Convert.ToInt32(tbid.Text);
            c.Deptname = tbname.Text.ToString();
            c.Deptlocation = tblocation.Text.ToString();
            c.Managerid = Convert.ToInt32(tbmid.Text);
            string msg = ob.adddin(c);//using stored procedure
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getData();
            tbid.Text = "";
            tbname.Text = "";
            tblocation.Text = "";
            tbmid.Text = "";

        }

        private void btninsert_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getData();
        }
    }
}
