﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace Main_proj.Model
{
    class DepartementLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["empdb"].ConnectionString;


        public List<Departement> getData()
        {
            List<Departement> li = new List<Departement>();
            string sql = "select * from Departement";
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while (sqr.Read())
                {
                    Departement ob = new Departement();
                    ob.Deptid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Deptname = sqr.GetValue(1).ToString();
                    ob.Deptlocation = sqr.GetValue(2).ToString();
                    ob.Managerid = Convert.ToInt32(sqr.GetValue(3));
                    
                    li.Add(ob);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("db not connected");

            }
            finally
            {
                conn.Close();
            }
            return li;
        }



        public string adddin(Departement c)
        {
            string msg = null;

            SqlConnection conn = new SqlConnection(conStr);
            MessageBox.Show("comming");
            string sql = "dininsertDepartement";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Deptid", SqlDbType.Int).Value = c.Deptid;
                cmd.Parameters.Add("@Deptname", SqlDbType.VarChar, 50).Value = c.Deptname;
                cmd.Parameters.Add("@Deptlocation", SqlDbType.VarChar,50).Value = c.Deptlocation;
                cmd.Parameters.Add("@Managerid", SqlDbType.Int).Value = c.Managerid;
                
                cmd.ExecuteNonQuery();



                msg = "data inserted seccessfully";
            }
            catch (Exception)
            {
                msg = "data is not inserted";
            }
            finally
            {
                conn.Close();
            }


            return msg;
        }


    }
}
