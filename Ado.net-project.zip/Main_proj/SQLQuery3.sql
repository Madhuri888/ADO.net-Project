﻿create procedure spdelete
