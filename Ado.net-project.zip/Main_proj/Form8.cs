﻿using Main_proj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj
{
    public partial class Form8 : Form
    {
        EmployeLogic ob;
        public Form8()
        {
            InitializeComponent();
            ob = new EmployeLogic();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

            dataGridView1.Visible = true;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {


            Employe emp = new Employe();
            int empid = Convert.ToInt32(tbid.Text);

            MessageBox.Show(ob.delete(empid));
            tbid.Text = "";
            dataGridView1.DataSource = ob.getAllData();


        }
    }
}
