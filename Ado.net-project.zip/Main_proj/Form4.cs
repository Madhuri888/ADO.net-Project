﻿using Main_proj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj
{
    public partial class Form4 : Form
    {
        EmployeLogic ob;
        public Form4()
        {
            InitializeComponent();
            ob = new EmployeLogic();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            int i;
            i =Convert.ToInt32(tbsearch.Text);
           Employe c= ob.search(i);
            if(c==null)
            {
                MessageBox.Show("search key not found..");
            }
            else
            {
                dataGridView1.Visible = true;
                List<Employe> li = new List<Employe>();
                li.Add(c);
                dataGridView1.DataSource = li;
                MessageBox.Show("search key  found");
            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
                
        }
    }
}
